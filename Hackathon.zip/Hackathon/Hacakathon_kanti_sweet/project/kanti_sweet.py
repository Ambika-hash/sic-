import pandas as pd
import matplotlib.pyplot as plt
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog

# Class for analyzing Kanti Sweets sales and inventory data
class KantiSweetsAnalyzer:
    def __init__(self, file_path):
        """
        Initializes the analyzer by loading the CSV data.
        """
        try:
            self.df = pd.read_csv(file_path)
        except FileNotFoundError:
            messagebox.showerror("Error", "File not found.")
            exit()

    def most_sold_sweet(self, month, year):
        """
        Displays a bar chart of the most sold sweets for a given month and year.
        """
        df_filtered = self.df[(self.df['month'].str.lower() == month.lower()) & (self.df['year'] == year)]
        if df_filtered.empty:
            messagebox.showinfo("Info", f"No data found for {month} {year}")
            return
        grouped = df_filtered.groupby('sweet_name')['quantity_sold'].sum().sort_values(ascending=False)
        top_sweet = grouped.idxmax()
        messagebox.showinfo("Suggestion", f"Consider stocking more of '{top_sweet}' to meet demand.")
        grouped.plot(kind='bar', color='skyblue')
        plt.title(f"Most Sold Sweets in {month} {year}")
        plt.xlabel("Sweet Name")
        plt.ylabel("Quantity Sold")
        plt.xticks(rotation=45)
        plt.grid(axis='y')
        plt.show()

    def highest_revenue_month(self, year):
        """
        Shows the month-wise revenue trend for a given year.
        """
        df_filtered = self.df[self.df['year'] == year]
        if df_filtered.empty:
            messagebox.showinfo("Info", f"No revenue data for {year}")
            return
        grouped = df_filtered.groupby('month')['revenue'].sum().sort_values(ascending=False)
        top_month = grouped.idxmax()
        messagebox.showinfo("Suggestion", f"Consider offering discounts or combos during low-performing months to boost revenue.")
        grouped.plot(kind='bar', color='lightgreen')
        plt.title(f"Monthly Revenue in {year}")
        plt.xlabel("Month")
        plt.ylabel("Total Revenue")
        plt.xticks(rotation=45)
        plt.grid(axis='y')
        plt.show()

    def compare_yearly_sales(self):
        """
        Compares yearly revenue and displays it as a bar chart.
        """
        grouped = self.df.groupby('year')['revenue'].sum().sort_index()
        top_year = grouped.idxmax()
        messagebox.showinfo("Suggestion", f"Review marketing and stock levels for years with lower revenue compared to {top_year}.")
        grouped.plot(kind='bar', color='orange')
        plt.title("Yearly Revenue Comparison")
        plt.xlabel("Year")
        plt.ylabel("Total Revenue")
        plt.xticks(rotation=0)
        plt.grid(axis='y')
        plt.show()

    def most_wasted_sweet(self, month, year):
        """
        Displays a bar chart of the least sold (wasted) sweets for a given month and year.
        """
        df_filtered = self.df[(self.df['month'].str.lower() == month.lower()) & (self.df['year'] == year)]
        if df_filtered.empty:
            messagebox.showinfo("Info", f"No data found for {month} {year}")
            return
        grouped = df_filtered.groupby('sweet_name')['quantity_sold'].sum().sort_values()
        least_sweet = grouped.idxmin()
        messagebox.showinfo("Suggestion", f"Consider reducing the price of '{least_sweet}' or bundling it in offers to improve sales.")
        grouped.plot(kind='bar', color='salmon')
        plt.title(f"Most Wasted Sweets in {month} {year}")
        plt.xlabel("Sweet Name")
        plt.ylabel("Quantity Sold")
        plt.xticks(rotation=45)
        plt.grid(axis='y')
        plt.show()

    def suggest_transfers(self):
        """
        Suggests inventory transfers from surplus to high-demand branches.
        Uses the latest available month and year from the dataset.
        """
        print("Entered here ")

        if self.df.empty:
            messagebox.showinfo("Info", "No data available.")
            return

        try:
            self.df['year'] = self.df['year'].astype(int)

            # Convert month names to numbers for correct sorting
            month_map = {
                'january': 1, 'february': 2, 'march': 3, 'april': 4, 'may': 5,
                'june': 6, 'july': 7, 'august': 8, 'september': 9,
                'october': 10, 'november': 11, 'december': 12
            }
            self.df['month_num'] = self.df['month'].str.lower().map(month_map)

            latest_entry = self.df.sort_values(['year', 'month_num'], ascending=False).iloc[0]
            latest_month = latest_entry['month']
            latest_year = latest_entry['year']
        except Exception as e:
            messagebox.showerror("Error", f"Could not determine latest data: {e}")
            return

        # Filter data for the latest month and year
        df_filtered = self.df[
            (self.df['month'].str.lower() == latest_month.lower()) &
            (self.df['year'] == latest_year)
        ]

        grouped = df_filtered.groupby(['sweet_name', 'branch'])['quantity_sold'].sum().reset_index()

        surplus, demand = {}, {}

        for _, row in grouped.iterrows():
            sweet, branch, qty = row['sweet_name'], row['branch'], row['quantity_sold']
            if qty < 60:
                surplus.setdefault(sweet, []).append((branch, qty))
            elif qty > 200:
                demand.setdefault(sweet, []).append((branch, qty))

        # Underperforming sweets for donation (from overall dataset)
        overall_wasted = self.df.groupby('sweet_name')['quantity_sold'].sum()
        wasted_for_donation = overall_wasted[overall_wasted < 100]

        if not wasted_for_donation.empty:
            donation_list = "\n".join(wasted_for_donation.index)
            messagebox.showinfo("Donation Suggestion", f"Consider donating the following underperforming sweets to an orphanage:\n{donation_list}")

        # Suggestions for transfers
        suggestions = []
        for sweet in surplus:
            if sweet in demand:
                for s_branch, s_qty in surplus[sweet]:
                    for d_branch, d_qty in demand[sweet]:
                        transfer_qty = min(60 - s_qty, d_qty - 200)
                        if transfer_qty > 0:
                            suggestions.append(f"Transfer {transfer_qty} of '{sweet}' from {s_branch} to {d_branch}")

        if suggestions:
            messagebox.showinfo("Suggested Transfers", "\n".join(suggestions))
        else:
            messagebox.showinfo("Info", "No transfers needed. Inventory is balanced.")


    def weekend_sales(self):
        """
        Analyzes weekend vs weekday sales and suggests pricing strategy.
        """
        self.df['day_type'] = self.df['days'].isin(['Saturday', 'Sunday']).map({True: 'Weekend', False: 'Weekday'})
        grouped = self.df.groupby('day_type')['quantity_sold'].sum()

        grouped.plot(kind='pie', autopct='%1.1f%%', colors=['skyblue', 'pink'])
        plt.title("Weekend vs Weekday Sales")
        plt.ylabel("")
        plt.show()

        if grouped['Weekend'] > grouped['Weekday']:
            messagebox.showinfo("Suggestion", "Increase price during **Weekend** due to higher sales.")
        else:
            messagebox.showinfo("Suggestion", "Increase price during **Weekday** to compensate for lower weekend performance.")

    def revenue_growth(self):
        """
        Calculates and displays the revenue growth from 2024 to 2025.
        """
        revenue_by_year = self.df.groupby('year')['revenue'].sum()
        if 2024 in revenue_by_year and 2025 in revenue_by_year:
            growth = ((revenue_by_year[2025] - revenue_by_year[2024]) / revenue_by_year[2024]) * 100
            messagebox.showinfo("Revenue Growth", f"Revenue growth from 2024 to 2025 is {growth:.2f}%")
            if growth < 0:
                messagebox.showinfo("Suggestion", "Revenue has declined. Consider running promotions or improving product quality.")
            else:
                messagebox.showinfo("Suggestion", "Revenue has increased. Keep up the good strategy!")
        else:
            messagebox.showinfo("Revenue Growth", "Insufficient data for revenue growth calculation.")
    def branch_data(self, month, year):
        """
        Evaluates branch-wise performance for the given month and year:
        - Total Revenue
        - Wastage Percentage
        - Best and Worst Performing Sweets
        - Suggestions for improvement
        """
        df_filtered = self.df[(self.df['month'].str.lower() == month.lower()) & (self.df['year'] == year)]
        if df_filtered.empty:
            messagebox.showinfo("Info", f"No data found for {month} {year}")
            return

        report = ""
        branches = df_filtered['branch'].unique()

        for branch in branches:
            df_branch = df_filtered[df_filtered['branch'] == branch]

            # Revenue and sales data
            total_revenue = df_branch['revenue'].sum()
            total_items = df_branch['quantity_sold'].sum()

            # Assuming wastage = sweets sold < 30 units
            waste_data = df_branch[df_branch['quantity_sold'] < 30]
            wasted_items = waste_data['quantity_sold'].sum()
            waste_pct = (wasted_items / total_items * 100) if total_items else 0

            # Top and worst performing sweets
            sweet_sales = df_branch.groupby('sweet_name')['quantity_sold'].sum()
            top_sweet = sweet_sales.idxmax()
            worst_sweet = sweet_sales.idxmin()

            report += f"\nBranch: {branch}\n"
            report += f"Total Revenue: ₹{total_revenue:.2f}\n"
            report += f"Wastage: {waste_pct:.2f}%\n"
            report += f"Best Selling Sweet: {top_sweet}\n"
            report += f"Most Wasted Sweet: {worst_sweet}\n"

            # Suggestions
            if waste_pct > 25:
                report += f"Suggestion: High wastage. Optimize inventory or reduce production.\n"
            else:
                report += f"Suggestion: Inventory is reasonably balanced.\n"

        messagebox.showinfo("Branch Health Report", report)

