import pandas as pd
import matplotlib.pyplot as plt
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog
from kanti_sweet import KantiSweetsAnalyzer


def show_welcome():
    welcome_window = tk.Tk()
    welcome_window.title("Welcome")
    welcome_window.configure(bg="#d8b4f8")  # Light lavender background

    tk.Label(
        welcome_window,
        text="🍰 Welcome to Kanti Sweets 🍰",
        font=("Arial", 16, "bold"),
        bg="#d8b4f8",
        fg="#3b0764"  # Deep purple text
    ).pack(padx=20, pady=20)

    tk.Button(
        welcome_window,
        text="Enter",
        font=("Arial", 12),
        command=welcome_window.destroy,
        bg="#a78bfa",      # Soft purple button
        fg="white",
        activebackground="#7c3aed",  # Deep purple on hover
        activeforeground="white",
        relief="raised",
        bd=2
    ).pack(pady=10)

    welcome_window.mainloop()

show_welcome()


def open_file():
    file_path = filedialog.askopenfilename(filetypes=[("CSV Files", "*.csv")])
    if not file_path:
        return
    analyzer = KantiSweetsAnalyzer(file_path)

    def run_option(option):
        if option == "Most Sold Sweet":
            m = simpledialog.askstring("Input", "Enter month:")
            y = simpledialog.askinteger("Input", "Enter year:")
            analyzer.most_sold_sweet(m, y)
        elif option == "Highest Revenue Month":
            y = simpledialog.askinteger("Input", "Enter year:")
            analyzer.highest_revenue_month(y)
        elif option == "Compare Yearly Revenue":
            analyzer.compare_yearly_sales()
        elif option == "Most Wasted Sweet":
            m = simpledialog.askstring("Input", "Enter month:")
            y = simpledialog.askinteger("Input", "Enter year:")
            analyzer.most_wasted_sweet(m, y)
        elif option == "Transfer Suggestions":
            analyzer.suggest_transfers()
        elif option == "Weekend vs Weekday Sales":
            analyzer.weekend_sales()
        elif option == "Revenue Growth":
            analyzer.revenue_growth()
        elif option == "Branch Data":
            m = simpledialog.askstring("Input", "Enter month:")
            y = simpledialog.askinteger("Input", "Enter year:")
            analyzer.branch_data(m, y)

    # Main Analysis Window
    app = tk.Tk()
    app.title("Kanti Sweets Analyzer")
    app.configure(bg="#f5e1f7")  # Light pink background

    tk.Label(
        app,
        text="Choose an analysis option:",
        font=("Arial", 14, "bold"),
        bg="#f5e1f7",
        fg="#4c1d95"  # Dark purple
    ).pack(pady=10)

    options = [
        "Most Sold Sweet",
        "Highest Revenue Month",
        "Compare Yearly Revenue",
        "Most Wasted Sweet",
        "Transfer Suggestions",
        "Weekend vs Weekday Sales",
        "Revenue Growth",
        "Branch Data"
    ]

    for opt in options:
        tk.Button(
            app,
            text=opt,
            width=30,
            font=("Arial", 11),
            command=lambda o=opt: run_option(o),
            bg="#c084fc",  # Violet
            fg="white",
            activebackground="#9333ea",  # Purple on hover
            activeforeground="white",
            relief="groove",
            bd=2
        ).pack(pady=5)

    app.mainloop()


# Entry Launcher Window
root = tk.Tk()
root.title("Kanti Sweets Analyzer Launcher")
root.configure(bg="#e9d5ff")  # Soft pastel lavender

tk.Label(
    root,
    text="Load CSV file to begin",
    font=("Arial", 14, "bold"),
    bg="#e9d5ff",
    fg="#4c1d95"
).pack(pady=20)

tk.Button(
    root,
    text="Open CSV File",
    command=open_file,
    font=("Arial", 12),
    bg="#a855f7",
    fg="white",
    activebackground="#7e22ce",
    activeforeground="white",
    relief="raised",
    bd=2
).pack(pady=10)

root.mainloop()
