import random
import pandas as pd

branches = ['Jayanagar', 'Indiranagar', 'Koramangala', 'Malleshwaram']
sweet_names = ['Kaju Katli', 'Rasgulla', 'Ladoo', 'Mysore Pak', 'Jalebi', 'Badam Halwa']
months = ['January', 'February', 'March',"April",'June','July','August','September','October','November','December']
years = [2025,2024,2023,2022,2021,2020]
days = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
sweet_id_map = {name: i + 101 for i, name in enumerate(sweet_names)}

rows = []

for _ in range(300):
    sweet_name = random.choice(sweet_names)
    sweet_id = sweet_id_map[sweet_name]
    quantity_sold = random.randint(20, 300)
    month = random.choice(months)
    branch = random.choice(branches)
    revenue = quantity_sold * random.randint(80, 120)
    year = random.choice(years)
    day = random.choice(days)


    rows.append({
        'sweet_id': sweet_id,
        'sweet_name': sweet_name,
        'quantity_sold': quantity_sold,
        'month': month,
        'year': year,
        'branch': branch,
        'revenue': revenue,
        'days' : day      
    })

df = pd.DataFrame(rows)
df.to_csv("D:\learning\sic-\project\kanti_sweets_multi_branch.csv", index=False)
print("done")